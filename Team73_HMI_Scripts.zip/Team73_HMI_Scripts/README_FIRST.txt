TEAM 73 - HMI HARDENING SCRIPTS + MONITOR
==========================================
Machine: HMI (IP-0A00208E), 10.0.32.142, Windows Server 2019 - ASSUME BREACH

!!! READ BEFORE RUNNING ANYTHING !!!
1. COMPETITION RULES: the HMI is an Assume Breach machine. Hardening steps "cannot be implemented until the day
   of the competition", and any change that disrupts scoring or Red Team engagement can cost points.
   Only run the CHANGE scripts on competition day, with team agreement, and after asking the help desk what
   changes are allowed on the HMI.
2. AI RULE: the rules ban AI tools for infrastructure defense. These scripts were prepared in advance with an
   AI assistant. Ask the help desk whether pre-made scripts are acceptable, read every script so you understand
   it, and do not use AI during the competition.
3. TAKE A SNAPSHOT before every change (limit: 2 reverts per VM per hour).
4. NEVER: change the historian password, IP or hostname, or touch score1/score2/patch (the scripts protect these).
5. These scripts have NOT been run on your machine. Script 00 checks them all for syntax errors - run it first.

SAFE TO RUN BEFORE COMPETITION DAY (read-only)
  00_PreCheck_and_Baseline.ps1    syntax-checks all scripts, health check, saves a baseline
  99_Verify_HMI_Health.ps1        health check (run after EVERY change)
  21_Check_Windows_Updates.ps1    lists missing updates (does nothing else unless you add -Install)
  HMI_Monitor\HMI_Monitor.ps1     the 10-minute malicious-activity monitor (read-only; see README_MONITOR.txt)

HOW TO RUN A SCRIPT
  1. Copy the folder to the HMI (e.g. C:\Users\blueteam\Desktop\HMI_Hardening_Scripts).
  2. Open PowerShell AS ADMINISTRATOR.
  3. cd C:\Users\blueteam\Desktop\HMI_Hardening_Scripts
  4. powershell -ExecutionPolicy Bypass -File .\04_Disable_Hidden_Admin_svc-hist.ps1
     (If Windows says the file is blocked: Get-ChildItem . -Recurse | Unblock-File)
  5. Every change script shows what it will do and asks you to type YES.
  6. To reverse a change:  powershell -ExecutionPolicy Bypass -File .\04_Disable_Hidden_Admin_svc-hist.ps1 -Undo
  7. Run 99_Verify_HMI_Health.ps1 and look at the HMI screens after each change.
  Log of everything done: Documents\HMI_Hardening\hardening_log.txt (use it for your reports).

SUGGESTED ORDER (lowest risk first)                                   RISK      UNDO
  01_Block_JMX_Port9000_Firewall.ps1        block port 9000           Low       -Undo
  03_Disable_Malicious_Scheduled_Tasks.ps1  2 fake SYSTEM tasks       Low       -Undo
  04_Disable_Hidden_Admin_svc-hist.ps1      hidden admin              Low       -Undo
  07_Disable_Former_Employee_Accounts.ps1   old.* accounts            Low       -Undo
  08_Remove_Unverified_RDP_Users.ps1        brady/hammon/walton RDP   Low       -Undo  (-AlsoDisable option)
  09_Disable_Builtin_Administrator.ps1      built-in Administrator    Low       -Undo
  10_Remove_network-admin_From_Admins.ps1   extra admin               Low       -Undo
  11_Disable_SSH.ps1                        SSH server                Low       -Undo
  12_Disable_SyncBreeze.ps1                 Sync Breeze + port 9121   Low       -Undo
  16_Disable_Print_Spooler.ps1              Print Spooler             Low       -Undo
  17_Disable_Remote_Registry.ps1            Remote Registry           Low       -Undo
  18_Disable_LLMNR.ps1                      LLMNR                     Low       -Undo
  19_Require_SMB_Signing.ps1                SMB signing               Low       -Undo
  05_Disable_Passwordless_Accounts.ps1      ~70 passwordless accts    Low-Med   -Undo  (-Keep name1,name2)
  06_Set_Password_Policy.ps1                min length 14, history    Low       -Undo  (-IncludeLockout = riskier)
  13_Lock_historian_svc_DB_Account.ps1      lock extra DB account     Low-Med   -Undo  (run BEFORE 15)
  14_Enable_Database_Query_Logging.ps1      DB activity log           Low       -Undo  (run BEFORE 15)
  20_Uninstall_Unneeded_Software.ps1        TFTP/Wireshark/etc.       Medium    none (snapshot)
  02_Disable_JMX_In_Ignition_Config.ps1     JMX off for good          Med-High  -Undo  (IGNITION RESTART)
  15_Restrict_historian_DB_Privileges.ps1   limit historian DB acct   HIGH      snapshot only!
  21_Check_Windows_Updates.ps1 -Install     Windows updates           HIGH      needs reboot; team decision
  22_Enable_Ignition_HTTPS_INSTRUCTIONS.txt HTTPS (manual steps)      Medium    manual

AFTER HARDENING
  Re-take the monitor baseline so only NEW changes alert:  HMI_Monitor.ps1 -NewBaseline

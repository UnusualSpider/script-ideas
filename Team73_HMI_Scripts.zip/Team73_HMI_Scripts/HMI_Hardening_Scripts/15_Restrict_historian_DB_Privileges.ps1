#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '15_Restrict_historian_DB_Privileges'
. "$PSScriptRoot\_common.ps1"

# Fix: the historian account has FULL ADMIN rights on the whole database server, from any address,
# and its password cannot be changed (competition rule). Compensating control: limit it to the
# historian database and only what Ignition needs. The password is NOT changed.
#
# !!! HIGH RISK - READ THIS !!!
# - After this runs, the historian account can no longer give its old rights back. -Undo will NOT work
#   unless someone has the MySQL root password. The real undo is reverting the AWS SNAPSHOT.
# - Run scripts 13 and 14 FIRST (they need the rights this script removes).
# - If HMI charts stop updating afterwards, revert the snapshot.
if ($Undo) {
    Write-Host 'Undo needs the MySQL root password (historian can no longer grant itself rights).' -ForegroundColor Yellow
    Write-Host 'If you have it, run as root:'
    Write-Host "  GRANT ALL PRIVILEGES ON *.* TO 'historian'@'%' WITH GRANT OPTION;"
    Write-Host 'Otherwise: revert the HMI to the snapshot taken before this script.'
    exit
}
Write-Host 'Current grants for historian:' -ForegroundColor Cyan
Invoke-HistSql "SHOW GRANTS FOR 'historian'@'%';" | ForEach-Object { Write-Host $_ }
$before = Invoke-HistSql "SELECT MAX(update_time) FROM information_schema.tables WHERE table_schema='historian';"
Write-Host ('Latest historian table update before change: ' + $before)
Confirm-Run 'Restrict historian@% to the historian database only (SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, DROP, temp tables, locks, views, execute)' 'HIGH. Cannot be undone without root or a snapshot. Charts may stop if Ignition needs more rights.' 'Revert the AWS snapshot'
$sql = "GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, DROP, CREATE TEMPORARY TABLES, LOCK TABLES, CREATE VIEW, SHOW VIEW, EXECUTE ON ``historian``.* TO 'historian'@'%'; " +
       "REVOKE ALL PRIVILEGES ON *.* FROM 'historian'@'%'; " +
       "REVOKE GRANT OPTION ON *.* FROM 'historian'@'%';"
$out = Invoke-HistSql $sql
if ($out) { Write-Host $out -ForegroundColor Red }
Write-Host 'New grants:' -ForegroundColor Cyan
Invoke-HistSql "SHOW GRANTS FOR 'historian'@'%';" | ForEach-Object { Write-Host $_ }
Write-Log 'historian privileges restricted to the historian database' 'Green'
Write-Host 'Waiting 90 seconds to confirm Ignition is still writing history...' -ForegroundColor Yellow
Start-Sleep 90
$after = Invoke-HistSql "SELECT MAX(update_time) FROM information_schema.tables WHERE table_schema='historian';"
Write-Host ('Latest historian table update now: ' + $after)
if ("$after" -eq "$before") { Write-Log 'WARNING: history may NOT be updating. Check the HMI Charts page and Ignition DB connection now.' 'Red' }
else { Write-Log 'History is still updating.' 'Green' }
Show-HmiHealth

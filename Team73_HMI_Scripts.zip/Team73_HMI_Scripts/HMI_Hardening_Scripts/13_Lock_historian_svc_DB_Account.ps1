#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '13_Lock_historian_svc_DB_Account'
. "$PSScriptRoot\_common.ps1"

# Fix: undocumented database account historian_svc can read and ADD plant history from any address.
# Locks the account (it stays in place and can be unlocked). Run this BEFORE script 15,
# because script 15 removes the historian account's right to manage users.
if ($Undo) {
    Invoke-HistSql "ALTER USER 'historian_svc'@'%' ACCOUNT UNLOCK;" | ForEach-Object { Write-Host $_ }
    Write-Log 'UNDO: historian_svc unlocked' 'Yellow'; exit
}
Write-Host 'Active connections by historian_svc right now (Ignition should NOT be one of them):' -ForegroundColor Cyan
Invoke-HistSql "SELECT id,user,host,db FROM information_schema.processlist WHERE user='historian_svc';" | ForEach-Object { Write-Host $_ }
Confirm-Run 'Lock the database account historian_svc' 'Low-Medium. Confirm the Ignition database connection uses "historian", not historian_svc.' 'Run with -Undo'
$out = Invoke-HistSql "ALTER USER 'historian_svc'@'%' ACCOUNT LOCK;"
if ($out) { Write-Host $out -ForegroundColor Red }
$chk = Invoke-HistSql "SELECT account_locked FROM mysql.user WHERE user='historian_svc';"
Write-Log ('historian_svc account_locked = ' + ($chk -join ',')) 'Green'

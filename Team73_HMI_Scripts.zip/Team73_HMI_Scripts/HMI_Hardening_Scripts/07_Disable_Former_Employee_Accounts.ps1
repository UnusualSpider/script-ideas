#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '07_Disable_Former_Employee_Accounts'
. "$PSScriptRoot\_common.ps1"

# Fix: accounts for former employees/contractors (old.*) are still enabled.
$state = 'state_07_old_accounts'
if ($Undo) {
    $prev = Get-State $state
    foreach ($n in @($prev)) { if ($n) { Enable-LocalUser -Name $n -ErrorAction SilentlyContinue } }
    Write-Log 'UNDO: re-enabled old.* accounts' 'Yellow'; exit
}
$targets = Get-LocalUser | Where-Object { $_.Name -like 'old.*' -and $_.Enabled }
if (-not $targets) { Write-Log 'No enabled old.* accounts.' 'Green'; exit }
Write-Host ('To disable: ' + ($targets.Name -join ', '))
Confirm-Run 'Disable former employee/contractor accounts (old.*)' 'Low.' 'Run with -Undo'
$targets | ForEach-Object { Disable-LocalUser -Name $_.Name }
Save-State $state @($targets.Name)
Write-Log ('Disabled: ' + ($targets.Name -join ', ')) 'Green'

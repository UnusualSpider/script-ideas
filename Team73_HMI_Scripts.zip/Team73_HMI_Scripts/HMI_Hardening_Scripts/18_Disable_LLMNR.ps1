#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '18_Disable_LLMNR'
. "$PSScriptRoot\_common.ps1"

# Fix: LLMNR (UDP 5355) lets attackers on the network trick the HMI into sending password hashes.
# Sets the policy "Turn off multicast name resolution". May need a reboot to fully apply.
$key = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient'
if ($Undo) { Remove-ItemProperty -Path $key -Name EnableMulticast -ErrorAction SilentlyContinue; Write-Log 'UNDO: EnableMulticast policy removed' 'Yellow'; exit }
Confirm-Run 'Turn off LLMNR (multicast name resolution) by policy' 'Low. Full effect may need a reboot; do NOT reboot without team agreement.' 'Run with -Undo'
New-Item -Path $key -Force | Out-Null
New-ItemProperty -Path $key -Name EnableMulticast -Value 0 -PropertyType DWord -Force | Out-Null
Write-Log 'LLMNR disabled by policy (EnableMulticast = 0)' 'Green'

#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '19_Require_SMB_Signing'
. "$PSScriptRoot\_common.ps1"

# Fix: SMB signing is not required, which allows credential-relay attacks.
if ($Undo) { Set-SmbServerConfiguration -RequireSecuritySignature $false -Force; Write-Log 'UNDO: SMB signing not required' 'Yellow'; exit }
Get-SmbServerConfiguration | Select-Object EnableSMB1Protocol,RequireSecuritySignature | Format-List
Confirm-Run 'Require SMB signing on the HMI' 'Low (SMB is not a scored service on the HMI).' 'Run with -Undo'
Set-SmbServerConfiguration -RequireSecuritySignature $true -Force
Write-Log 'SMB signing now required' 'Green'

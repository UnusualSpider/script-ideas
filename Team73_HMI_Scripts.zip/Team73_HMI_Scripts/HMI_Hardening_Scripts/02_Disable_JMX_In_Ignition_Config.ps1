#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '02_Disable_JMX_In_Ignition_Config'
. "$PSScriptRoot\_common.ps1"

# Fix: turns off the unauthenticated Java JMX remote-management feature in Ignition's startup config.
# How: in ignition.conf, renames the JMX settings (e.g. -Dcom.sun.management.jmxremote.port=9000 becomes
# -Ddisabled.com.sun.management.jmxremote.port=9000) so Java ignores them. Line numbering is kept intact.
# REQUIRES AN IGNITION RESTART: the HMI screens go blank for a few minutes.
$conf = 'C:\Program Files\Inductive Automation\Ignition\data\ignition.conf'
if (-not (Test-Path $conf)) { Write-Log "Config not found: $conf" 'Red'; exit 1 }

function Restart-Ignition {
    Write-Log 'Restarting the Ignition service...' 'Yellow'
    Restart-Service Ignition -Force
    $deadline = (Get-Date).AddMinutes(6)
    do { Start-Sleep 10; $up = Get-NetTCPConnection -LocalPort 8088 -State Listen -ErrorAction SilentlyContinue }
    until ($up -or (Get-Date) -gt $deadline)
    if ($up) { Write-Log 'Ignition is back (port 8088 listening).' 'Green' } else { Write-Log 'Ignition did not come back within 6 minutes. Check it now!' 'Red' }
}

if ($Undo) {
    $bak = Get-ChildItem (Split-Path $conf) -Filter 'ignition.conf.bak-*' | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $bak) { Write-Log 'No backup found.' 'Red'; exit 1 }
    Copy-Item $bak.FullName $conf -Force
    Write-Log ('UNDO: restored ' + $bak.Name) 'Yellow'
    if ((Read-Host 'Restart Ignition now so the change takes effect? (YES/no)') -eq 'YES') { Restart-Ignition }
    exit
}

$lines = [System.IO.File]::ReadAllLines($conf)
$pattern = '-D(com\.sun\.management\.jmxremote|java\.rmi\.server\.hostname)'
$hits = $lines | Where-Object { $_ -match $pattern -and $_ -notmatch '^\s*#' }
if (-not $hits) {
    Write-Log 'No JMX settings found in ignition.conf. Lines mentioning jmx:' 'Yellow'
    $lines | Select-String -Pattern 'jmx' | ForEach-Object { Write-Host $_ }
    exit
}
Write-Host 'These lines will be changed:' -ForegroundColor Cyan
$hits | ForEach-Object { Write-Host ('  ' + $_) }
Confirm-Run 'Disable Java JMX remote management in ignition.conf, then restart Ignition' 'MEDIUM-HIGH. Ignition restart = HMI screens and data pause for a few minutes. Do it in a quiet moment.' 'Run with -Undo (restores the backup)'

$bakName = $conf + '.bak-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
Copy-Item $conf $bakName
Write-Log ('Backup saved: ' + $bakName)
$new = $lines | ForEach-Object {
    if ($_ -notmatch '^\s*#') {
        ($_ -replace '-Dcom\.sun\.management\.jmxremote', '-Ddisabled.com.sun.management.jmxremote') -replace '-Djava\.rmi\.server\.hostname', '-Ddisabled.java.rmi.server.hostname'
    } else { $_ }
}
[System.IO.File]::WriteAllLines($conf, [string[]]$new, (New-Object System.Text.UTF8Encoding($false)))
Write-Log 'ignition.conf updated.' 'Green'
if ((Read-Host 'Restart Ignition now? (YES/no)') -eq 'YES') {
    Restart-Ignition
    $p9000 = Get-NetTCPConnection -LocalPort 9000 -State Listen -ErrorAction SilentlyContinue
    if ($p9000) { Write-Log 'Port 9000 is STILL listening. JMX may be set elsewhere; keep script 01 firewall rule in place.' 'Red' }
    else { Write-Log 'Port 9000 is no longer listening. JMX disabled.' 'Green' }
} else { Write-Log 'Change saved but NOT active until Ignition restarts.' 'Yellow' }
Show-HmiHealth

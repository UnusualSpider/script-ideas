#Requires -RunAsAdministrator
param([switch]$Undo, [switch]$IncludeLockout)
$Global:ScriptName = '06_Set_Password_Policy'
. "$PSScriptRoot\_common.ps1"

# Fix: no password rules (minimum length 0, no history).
# Sets minimum length 14 and remembers the last 24 passwords. Applies to NEW passwords only.
# Account LOCKOUT is OFF by default in this script because an attacker could deliberately lock out
# score1/score2 and cost service points. Add -IncludeLockout to also lock accounts after 10 bad tries.
if ($Undo) {
    net accounts /minpwlen:0 /uniquepw:0 | Out-Null
    net accounts /lockoutthreshold:0 | Out-Null
    Write-Log 'UNDO: minimum length 0, no history, no lockout' 'Yellow'; exit
}
Write-Host 'Current policy:' -ForegroundColor Cyan; net accounts
$risk = 'Low.'
if ($IncludeLockout) { $risk = 'MEDIUM: lockout could be abused to lock scoring accounts.' }
Confirm-Run 'Set minimum password length 14 and password history 24' $risk 'Run with -Undo'
net accounts /minpwlen:14 /uniquepw:24 | Out-Null
Write-Log 'Set minimum password length 14, history 24' 'Green'
if ($IncludeLockout) {
    net accounts /lockoutthreshold:10 | Out-Null
    net accounts /lockoutwindow:15 /lockoutduration:15 | Out-Null
    Write-Log 'Set lockout: 10 bad attempts, 15 minutes' 'Green'
}
net accounts

#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '01_Block_JMX_Port9000_Firewall'
. "$PSScriptRoot\_common.ps1"

# Fix: Ignition's Java remote-management port 9000 is open to the network with no password.
# This adds a Windows Firewall rule that blocks inbound TCP 9000 from the network.
# Local (same-machine) connections are not affected. No Ignition restart needed.
$rule = 'HMI-Harden Block JMX TCP 9000'
if ($Undo) {
    Remove-NetFirewallRule -DisplayName $rule -ErrorAction SilentlyContinue
    Write-Log "UNDO: removed firewall rule '$rule'" 'Yellow'; exit
}
Confirm-Run 'Block inbound TCP port 9000 (Java JMX) in Windows Firewall' 'Low. Blocks a port, not an IP. Ignition keeps running.' 'Run this script with -Undo'
if (Get-NetFirewallRule -DisplayName $rule -ErrorAction SilentlyContinue) { Write-Log 'Rule already exists. Nothing to do.' 'Yellow'; exit }
New-NetFirewallRule -DisplayName $rule -Direction Inbound -Protocol TCP -LocalPort 9000 -Action Block -Profile Any | Out-Null
Write-Log "Added firewall rule '$rule' (inbound TCP 9000 blocked)" 'Green'
Show-HmiHealth

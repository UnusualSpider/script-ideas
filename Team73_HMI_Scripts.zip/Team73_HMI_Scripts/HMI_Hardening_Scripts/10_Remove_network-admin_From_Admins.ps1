#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '10_Remove_network-admin_From_Admins'
. "$PSScriptRoot\_common.ps1"

# Fix: too many administrators. Removes 'network-admin' from the local Administrators group.
# score1, score2 and patch are protected by competition rules and are NOT touched.
$u = 'network-admin'
if ($Undo) { Add-LocalGroupMember -Group Administrators -Member $u -ErrorAction SilentlyContinue; Write-Log "UNDO: added $u back to Administrators" 'Yellow'; exit }
Write-Host 'Services running as this account (should be none):'
Get-CimInstance Win32_Service | Where-Object { $_.StartName -match 'network-admin' } | Select-Object Name,StartName | Format-Table -AutoSize
Confirm-Run "Remove $u from Administrators" 'Low. Confirm with your team nobody uses it.' 'Run with -Undo'
Remove-LocalGroupMember -Group Administrators -Member $u
Write-Log "Removed $u from Administrators" 'Green'

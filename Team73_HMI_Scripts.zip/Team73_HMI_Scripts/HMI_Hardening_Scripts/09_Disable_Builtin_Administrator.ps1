#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '09_Disable_Builtin_Administrator'
. "$PSScriptRoot\_common.ps1"

# Fix: the built-in Administrator account is enabled. The team uses the named 'blueteam' admin instead.
if ($Undo) { Enable-LocalUser -Name 'Administrator'; Write-Log 'UNDO: enabled Administrator' 'Yellow'; exit }
$bt = Get-LocalUser -Name 'blueteam'
$isAdmin = Get-LocalGroupMember Administrators | Where-Object { $_.Name -like '*\blueteam' }
if (-not ($bt.Enabled -and $isAdmin)) { Write-Log 'STOP: blueteam is not an enabled administrator. Not disabling Administrator.' 'Red'; exit 1 }
Confirm-Run 'Disable the built-in Administrator account' 'Low (blueteam remains an admin).' 'Run with -Undo'
Disable-LocalUser -Name 'Administrator'
Write-Log 'Disabled built-in Administrator' 'Green'

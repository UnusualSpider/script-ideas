#Requires -RunAsAdministrator
param([switch]$Undo, [switch]$Install)
$Global:ScriptName = '21_Check_Windows_Updates'
. "$PSScriptRoot\_common.ps1"

# Fix: Windows updates are about 6 months out of date.
# By default this only LISTS missing updates (read-only). Add -Install to download and install them.
# Installing usually needs a REBOOT, which stops the HMI for several minutes. This script never reboots.
if ($Undo) { Write-Host 'Uninstall a specific update with: wusa /uninstall /kb:NUMBER  (or revert the snapshot)'; exit }
Write-Host 'Searching for missing updates (can take several minutes)...' -ForegroundColor Cyan
try {
    $session  = New-Object -ComObject Microsoft.Update.Session
    $searcher = $session.CreateUpdateSearcher()
    $result   = $searcher.Search("IsInstalled=0 and Type='Software' and IsHidden=0")
} catch { Write-Log ('Update search failed (no internet/WSUS?): ' + $_.Exception.Message) 'Red'; exit 1 }
if ($result.Updates.Count -eq 0) { Write-Log 'No missing updates found.' 'Green'; exit }
$list = @(); foreach ($u in $result.Updates) { $list += $u.Title }
$list | ForEach-Object { Write-Host ('  - ' + $_) }
Write-Log ('Missing updates: ' + $list.Count)
if (-not $Install) { Write-Host 'Run again with -Install to install them.' -ForegroundColor Yellow; exit }
Confirm-Run 'Download and install the updates listed above' 'HIGH. A reboot will probably be needed (HMI down for minutes). Do not reboot without team agreement.' 'wusa /uninstall /kb:NUMBER or revert snapshot'
$coll = New-Object -ComObject Microsoft.Update.UpdateColl
foreach ($u in $result.Updates) { if (-not $u.EulaAccepted) { $u.AcceptEula() }; [void]$coll.Add($u) }
$dl = $session.CreateUpdateDownloader(); $dl.Updates = $coll; [void]$dl.Download()
$inst = $session.CreateUpdateInstaller(); $inst.Updates = $coll; $r = $inst.Install()
Write-Log ('Install result code: ' + $r.ResultCode + ' (2 = succeeded). Reboot required: ' + $r.RebootRequired) 'Green'

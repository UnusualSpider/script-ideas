#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '12_Disable_SyncBreeze'
. "$PSScriptRoot\_common.ps1"

# Fix: unneeded Sync Breeze Server runs as SYSTEM and listens on port 9121.
# Stops and disables the service and blocks port 9121 (TCP and UDP). Uninstalling is in script 20.
$svc = 'Sync Breeze Server'
$rT = 'HMI-Harden Block SyncBreeze TCP 9121'; $rU = 'HMI-Harden Block SyncBreeze UDP 9121'
if ($Undo) {
    Remove-NetFirewallRule -DisplayName $rT,$rU -ErrorAction SilentlyContinue
    Set-Service $svc -StartupType Automatic; Start-Service $svc
    Write-Log 'UNDO: Sync Breeze re-enabled, firewall rules removed' 'Yellow'; exit
}
Confirm-Run 'Stop/disable Sync Breeze Server and block port 9121' 'Low (not a plant service and not a scored service).' 'Run with -Undo'
Stop-Service $svc -Force -ErrorAction SilentlyContinue
Set-Service $svc -StartupType Disabled
if (-not (Get-NetFirewallRule -DisplayName $rT -ErrorAction SilentlyContinue)) { New-NetFirewallRule -DisplayName $rT -Direction Inbound -Protocol TCP -LocalPort 9121 -Action Block | Out-Null }
if (-not (Get-NetFirewallRule -DisplayName $rU -ErrorAction SilentlyContinue)) { New-NetFirewallRule -DisplayName $rU -Direction Inbound -Protocol UDP -LocalPort 9121 -Action Block | Out-Null }
Write-Log 'Sync Breeze stopped, disabled, port 9121 blocked' 'Green'

#Requires -RunAsAdministrator
param([switch]$Undo, [switch]$AlsoDisable)
$Global:ScriptName = '08_Remove_Unverified_RDP_Users'
. "$PSScriptRoot\_common.ps1"

# Fix: unverified accounts brady, hammon, walton can log in with Remote Desktop.
# Removes them from "Remote Desktop Users". Add -AlsoDisable to disable the accounts too.
$names = @('brady','hammon','walton')
$state = 'state_08_rdp'
if ($Undo) {
    $prev = Get-State $state
    foreach ($n in @($prev.removed))  { if ($n) { Add-LocalGroupMember -Group 'Remote Desktop Users' -Member $n -ErrorAction SilentlyContinue } }
    foreach ($n in @($prev.disabled)) { if ($n) { Enable-LocalUser -Name $n -ErrorAction SilentlyContinue } }
    Write-Log 'UNDO: restored RDP membership / enabled accounts' 'Yellow'; exit
}
Write-Host 'Current Remote Desktop Users:'; Get-LocalGroupMember 'Remote Desktop Users' | Select-Object Name
Write-Host 'Active sessions:'; query user
Confirm-Run ('Remove ' + ($names -join ', ') + ' from Remote Desktop Users' + $(if ($AlsoDisable) {' and disable them'} else {''})) 'Low. Confirm with your team these are not real staff.' 'Run with -Undo'
$removed = @(); $disabled = @()
foreach ($n in $names) {
    $m = Get-LocalGroupMember 'Remote Desktop Users' | Where-Object { $_.Name -like "*\$n" }
    if ($m) { Remove-LocalGroupMember -Group 'Remote Desktop Users' -Member $n; $removed += $n; Write-Log "Removed $n from Remote Desktop Users" 'Green' }
    if ($AlsoDisable -and (Get-LocalUser -Name $n -ErrorAction SilentlyContinue).Enabled) { Disable-LocalUser -Name $n; $disabled += $n; Write-Log "Disabled $n" 'Green' }
}
Save-State $state @{ removed = $removed; disabled = $disabled }
Write-Host 'If one of them has an active session above, log it off with:  logoff <ID>' -ForegroundColor Yellow

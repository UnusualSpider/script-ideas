#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '11_Disable_SSH'
. "$PSScriptRoot\_common.ps1"

# Fix: OpenSSH server is running and open to everyone, but is not part of the plant.
$rules = @('SSH','OpenSSH SSH Server (sshd)')
if ($Undo) {
    Set-Service sshd -StartupType Automatic; Start-Service sshd
    foreach ($r in $rules) { Enable-NetFirewallRule -DisplayName $r -ErrorAction SilentlyContinue }
    Write-Log 'UNDO: sshd enabled and started; firewall rules re-enabled' 'Yellow'; exit
}
Confirm-Run 'Stop and disable the sshd service and its firewall rules' 'Low. Make sure no teammate uses SSH to this box.' 'Run with -Undo'
Stop-Service sshd -Force -ErrorAction SilentlyContinue
Set-Service sshd -StartupType Disabled
foreach ($r in $rules) { if (Get-NetFirewallRule -DisplayName $r -ErrorAction SilentlyContinue) { Disable-NetFirewallRule -DisplayName $r; Write-Log "Disabled firewall rule '$r'" 'Green' } }
Write-Log 'sshd stopped and disabled' 'Green'

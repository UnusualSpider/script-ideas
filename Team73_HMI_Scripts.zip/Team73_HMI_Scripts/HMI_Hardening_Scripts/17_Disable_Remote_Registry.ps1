#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '17_Disable_Remote_Registry'
. "$PSScriptRoot\_common.ps1"

# Fix: Remote Registry is set to start automatically (lets remote users edit the registry).
if ($Undo) { Set-Service RemoteRegistry -StartupType Automatic; Write-Log 'UNDO: RemoteRegistry set to Automatic' 'Yellow'; exit }
Confirm-Run 'Stop and disable the Remote Registry service' 'Low.' 'Run with -Undo'
Stop-Service RemoteRegistry -Force -ErrorAction SilentlyContinue
Set-Service RemoteRegistry -StartupType Disabled
Write-Log 'Remote Registry stopped and disabled' 'Green'

#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '00_PreCheck_and_Baseline'
. "$PSScriptRoot\_common.ps1"

# READ-ONLY (except saving files to Documents). Safe to run before competition day.
# 1) Checks every script in this folder for syntax errors.
# 2) Shows HMI health.
# 3) Saves a baseline of "normal" to Documents\HMI_Hardening\Baseline.

Write-Host '--- Syntax check of all scripts ---' -ForegroundColor Cyan
Get-ChildItem $PSScriptRoot -Filter *.ps1 | ForEach-Object {
    $errs = $null
    [System.Management.Automation.Language.Parser]::ParseFile($_.FullName, [ref]$null, [ref]$errs) | Out-Null
    if ($errs -and $errs.Count -gt 0) { Write-Host ('FAIL  ' + $_.Name + ' : ' + $errs[0].Message) -ForegroundColor Red }
    else { Write-Host ('OK    ' + $_.Name) -ForegroundColor Green }
}

Show-HmiHealth

$b = Join-Path $Global:HLogDir 'Baseline'
New-Item $b -ItemType Directory -Force | Out-Null
Get-LocalUser | Select-Object Name,Enabled,PasswordRequired | Export-Csv "$b\users.csv" -NoTypeInformation
Get-LocalGroupMember Administrators | Select-Object Name | Export-Csv "$b\admins.csv" -NoTypeInformation
Get-LocalGroupMember 'Remote Desktop Users' | Select-Object Name | Export-Csv "$b\rdp.csv" -NoTypeInformation
Get-ScheduledTask | Select-Object TaskName,TaskPath,State | Export-Csv "$b\tasks.csv" -NoTypeInformation
Get-Service | Select-Object Name,Status,StartType | Export-Csv "$b\services.csv" -NoTypeInformation
Get-NetTCPConnection -State Listen | Sort-Object LocalPort -Unique | Select-Object LocalPort | Export-Csv "$b\ports.csv" -NoTypeInformation
Get-NetFirewallRule -Enabled True | Select-Object DisplayName,Direction,Action | Export-Csv "$b\fw.csv" -NoTypeInformation
net accounts | Out-File "$b\net_accounts.txt"
Get-SmbServerConfiguration | Select-Object EnableSMB1Protocol,RequireSecuritySignature | Out-File "$b\smb.txt"
Invoke-HistSql "SELECT user,host,account_locked FROM mysql.user;" | Out-File "$b\db_users.txt"
Invoke-HistSql "SHOW GRANTS FOR 'historian'@'%';" | Out-File "$b\db_grants_historian.txt"
Write-Log ('Baseline saved to ' + $b) 'Green'

#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '14_Enable_Database_Query_Logging'
. "$PSScriptRoot\_common.ps1"

# Fix: database activity logging is off, so changes to plant history are not recorded.
# Turns on the MySQL general query log until MySQL restarts. Run BEFORE script 15.
# Note: the log grows over the day; that is fine for one competition day.
if ($Undo) { Invoke-HistSql "SET GLOBAL general_log = 'OFF';" | Out-Null; Write-Log 'UNDO: general_log OFF' 'Yellow'; exit }
Confirm-Run 'Turn on the MySQL general query log' 'Low (small disk/performance cost).' 'Run with -Undo'
$out = Invoke-HistSql "SET GLOBAL general_log = 'ON';"
if ($out) { Write-Host $out -ForegroundColor Red }
$f = Invoke-HistSql "SELECT @@general_log, @@general_log_file, @@datadir;"
Write-Log ('general_log, file, datadir = ' + ($f -join ' ')) 'Green'
Write-Host 'The log file is in the MySQL data folder (usually C:\ProgramData\MySQL\MySQL Server 8.4\Data).'

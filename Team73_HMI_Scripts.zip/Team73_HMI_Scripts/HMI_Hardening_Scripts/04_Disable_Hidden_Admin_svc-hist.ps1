#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '04_Disable_Hidden_Admin_svc-hist'
. "$PSScriptRoot\_common.ps1"

# Fix: hidden local admin 'svc-hist$' (named to look like a computer account).
$u = 'svc-hist$'
if ($Undo) {
    Enable-LocalUser -Name $u -ErrorAction SilentlyContinue
    Add-LocalGroupMember -Group Administrators -Member $u -ErrorAction SilentlyContinue
    Write-Log "UNDO: re-enabled $u and added it back to Administrators" 'Yellow'; exit
}
if (-not (Get-LocalUser -Name $u -ErrorAction SilentlyContinue)) { Write-Log "$u not found." 'Yellow'; exit }
Write-Host 'Services running as this account (should be none):'
Get-CimInstance Win32_Service | Where-Object { $_.StartName -match 'svc-hist' } | Select-Object Name,StartName | Format-Table -AutoSize
Confirm-Run "Remove $u from Administrators and disable it" 'Low (no service uses it).' 'Run with -Undo'
Remove-LocalGroupMember -Group Administrators -Member $u -ErrorAction SilentlyContinue
Disable-LocalUser -Name $u
Write-Log "Removed $u from Administrators and disabled it" 'Green'

#Requires -RunAsAdministrator
param([switch]$Undo, [string[]]$Keep = @())
$Global:ScriptName = '05_Disable_Passwordless_Accounts'
. "$PSScriptRoot\_common.ps1"

# Fix: about 70 enabled local accounts have "password not required".
# Disables enabled accounts with PasswordRequired = False (never touches score1, score2, patch, blueteam).
# Add names to -Keep to leave specific accounts enabled, e.g.  .\05_...ps1 -Keep 'dana.liu','emma.cho'
$state = 'state_05_passwordless'
if ($Undo) {
    $prev = Get-State $state
    if (-not $prev) { Write-Log 'No saved state; nothing to undo.' 'Yellow'; exit }
    foreach ($n in $prev) { Enable-LocalUser -Name $n -ErrorAction SilentlyContinue }
    Write-Log ('UNDO: re-enabled ' + @($prev).Count + ' accounts') 'Yellow'; exit
}
$skip = $Global:Protected + $Keep + @('Administrator','Guest','DefaultAccount','WDAGUtilityAccount')
$targets = Get-LocalUser | Where-Object { $_.Enabled -and -not $_.PasswordRequired -and $skip -notcontains $_.Name }
if (-not $targets) { Write-Log 'No enabled passwordless accounts found.' 'Green'; exit }
Write-Host ('Accounts to disable (' + @($targets).Count + '):') -ForegroundColor Cyan
($targets.Name -join ', ') | Write-Host
Confirm-Run 'Disable all enabled accounts that do not require a password' 'Low-Medium. Make sure no teammate or scoring check uses one of these accounts.' 'Run with -Undo'
$done = @()
foreach ($t in $targets) { Disable-LocalUser -Name $t.Name; $done += $t.Name }
Save-State $state $done
Write-Log ('Disabled ' + $done.Count + ' passwordless accounts') 'Green'
# Also make sure blank passwords cannot be used over the network (Windows default = 1).
$lsa = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'
$v = (Get-ItemProperty $lsa -Name LimitBlankPasswordUse -ErrorAction SilentlyContinue).LimitBlankPasswordUse
if ($v -ne 1) { Set-ItemProperty $lsa -Name LimitBlankPasswordUse -Value 1 -Type DWord; Write-Log ('Set LimitBlankPasswordUse = 1 (was ' + $v + ')') 'Green' }
else { Write-Log 'LimitBlankPasswordUse already 1 (blank passwords limited to console).' }

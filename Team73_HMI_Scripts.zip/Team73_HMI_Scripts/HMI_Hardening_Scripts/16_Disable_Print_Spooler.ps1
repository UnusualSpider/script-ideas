#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '16_Disable_Print_Spooler'
. "$PSScriptRoot\_common.ps1"

# Fix: Print Spooler runs on a server that never prints (PrintNightmare-class flaws).
if ($Undo) { Set-Service Spooler -StartupType Automatic; Start-Service Spooler; Write-Log 'UNDO: Spooler enabled and started' 'Yellow'; exit }
Confirm-Run 'Stop and disable the Print Spooler service' 'Low.' 'Run with -Undo'
Stop-Service Spooler -Force -ErrorAction SilentlyContinue
Set-Service Spooler -StartupType Disabled
Write-Log 'Print Spooler stopped and disabled' 'Green'

#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '20_Uninstall_Unneeded_Software'
. "$PSScriptRoot\_common.ps1"

# Fix: unneeded programs on a control-system machine: TFTP server, Wireshark, Npcap, Cisco Webex,
# Google Chrome, SubInAcl, Sync Breeze. Asks about EACH program separately. NO UNDO (reinstall needed).
# Never removes Ignition, MySQL, or AWS components.
$patterns = 'TFTP','Wireshark','Npcap','Webex','Google Chrome','SubInAcl','Sync Breeze'
$keys = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
$apps = Get-ItemProperty $keys -ErrorAction SilentlyContinue | Where-Object {
    $n = $_.DisplayName; $n -and ($patterns | Where-Object { $n -like "*$_*" }) -and $n -notmatch 'Ignition|MySQL|Amazon|AWS'
}
if ($Undo) { Write-Host 'No undo: reinstall the program, or revert the snapshot.'; exit }
if (-not $apps) { Write-Log 'None of the target programs were found.' 'Green'; exit }
$apps | Select-Object DisplayName,DisplayVersion | Format-Table -AutoSize
Confirm-Run 'Uninstall the programs listed above (you will be asked about each one)' 'Medium. Some uninstallers open a window you must click through. No undo.' 'Reinstall or revert snapshot'
foreach ($a in $apps) {
    if ((Read-Host ('Uninstall "' + $a.DisplayName + '"? (YES/no)')) -ne 'YES') { continue }
    $cmd = $a.QuietUninstallString
    if (-not $cmd) { $cmd = $a.UninstallString }
    if (-not $cmd) { Write-Log ('No uninstall command for ' + $a.DisplayName) 'Yellow'; continue }
    if ($cmd -match 'MsiExec\.exe\s+/[IX](\{[0-9A-Fa-f\-]+\})') { $cmd = 'MsiExec.exe /X' + $Matches[1] + ' /qn /norestart' }
    Write-Log ('Running: ' + $cmd)
    Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', $cmd -Wait
    Write-Log ('Uninstall finished for ' + $a.DisplayName + ' (check it is gone)') 'Green'
}

# _common.ps1 - shared helpers for the HMI hardening scripts (Team 73).
# Dot-sourced by every numbered script. Do not run this file by itself.

$Global:HLogDir   = Join-Path $env:USERPROFILE 'Documents\HMI_Hardening'
$Global:Protected = @('score1','score2','patch','blueteam')   # never modify these accounts
$Global:MySqlExe  = 'C:\Program Files\MySQL\MySQL Server 8.4\bin\mysql.exe'
New-Item $Global:HLogDir -ItemType Directory -Force | Out-Null

function Write-Log {
    param([string]$Msg, [string]$Color = 'Gray')
    $line = '{0}  [{1}]  {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Global:ScriptName, $Msg
    Add-Content -Path (Join-Path $Global:HLogDir 'hardening_log.txt') -Value $line
    Write-Host $line -ForegroundColor $Color
}

function Confirm-Run {
    param([string]$Action, [string]$Risk, [string]$UndoNote)
    Write-Host ''
    Write-Host ('=== ' + $Global:ScriptName + ' ===') -ForegroundColor Cyan
    Write-Host ('Action : ' + $Action)
    Write-Host ('Risk   : ' + $Risk) -ForegroundColor Yellow
    if ($UndoNote) { Write-Host ('Undo   : ' + $UndoNote) }
    Write-Host 'Before you continue, confirm ALL of these:' -ForegroundColor Yellow
    Write-Host '  1. It is competition day (Assume Breach machines may not be changed before then).'
    Write-Host '  2. Your team agreed to this change.'
    Write-Host '  3. The help desk / rules allow this change on the HMI.'
    Write-Host '  4. You took an AWS snapshot of the HMI.'
    $a = Read-Host 'Type YES to continue'
    if ($a -ne 'YES') { Write-Host 'Cancelled. Nothing was changed.' -ForegroundColor Yellow; exit 1 }
}

function Save-State { param([string]$Name, $Obj)
    $Obj | ConvertTo-Json -Depth 5 | Set-Content -Path (Join-Path $Global:HLogDir ($Name + '.json'))
}
function Get-State { param([string]$Name)
    $p = Join-Path $Global:HLogDir ($Name + '.json')
    if (Test-Path $p) { return (Get-Content $p -Raw | ConvertFrom-Json) } else { return $null }
}

function Invoke-HistSql {
    # Runs SQL as the historian account. Never changes the historian password.
    param([string]$Sql)
    $ErrorActionPreference = 'Continue'
    $out = & $Global:MySqlExe -u historian '-pCyberForce2026!' -N -e $Sql 2>&1
    $out | ForEach-Object { "$_" } | Where-Object { $_ -notmatch 'Using a password on the command line' }
}

function Show-HmiHealth {
    Write-Host ''
    Write-Host '--- HMI health check ---' -ForegroundColor Cyan
    foreach ($s in 'Ignition','MySQL84') {
        $svc = Get-Service $s -ErrorAction SilentlyContinue
        if ($svc) { Write-Host ('{0,-10} {1}' -f $s, $svc.Status) -ForegroundColor ($(if ($svc.Status -eq 'Running') {'Green'} else {'Red'})) }
        else { Write-Host ('{0,-10} NOT FOUND' -f $s) -ForegroundColor Red }
    }
    $p8088 = Get-NetTCPConnection -LocalPort 8088 -State Listen -ErrorAction SilentlyContinue
    Write-Host ('Ignition web 8088 listening: ' + [bool]$p8088) -ForegroundColor ($(if ($p8088) {'Green'} else {'Red'}))
    Write-Host 'Now look at the HMI screens (Perspective) and confirm values are still updating.' -ForegroundColor Yellow
}

#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '99_Verify_HMI_Health'
. "$PSScriptRoot\_common.ps1"

# READ-ONLY. Run after every change to confirm the HMI still works.
Show-HmiHealth
Write-Host ''
Write-Host '--- Is Ignition connected to the PLCs? (existing connections only) ---' -ForegroundColor Cyan
Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue | Where-Object { $_.RemoteAddress -in '10.0.32.143','10.0.32.144' } |
    Select-Object RemoteAddress,RemotePort,@{n='Program';e={(Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).Name}} | Format-Table -AutoSize
Write-Host 'Expect java (Ignition) connected to PLC 1 (10.0.32.144:502). If empty, check the Gateway Devices page.'
Write-Host ''
Write-Host '--- Historian still updating? ---' -ForegroundColor Cyan
Invoke-HistSql "SELECT table_name, table_rows, update_time FROM information_schema.tables WHERE table_schema='historian';" | ForEach-Object { Write-Host $_ }
Write-Host ''
Write-Host '--- Protection status ---' -ForegroundColor Cyan
Get-MpComputerStatus | Select-Object AntivirusEnabled,RealTimeProtectionEnabled | Format-List
Get-NetFirewallProfile | Select-Object Name,Enabled | Format-Table -AutoSize
Write-Host '--- Rules added by these scripts ---' -ForegroundColor Cyan
Get-NetFirewallRule -DisplayName 'HMI-Harden*' -ErrorAction SilentlyContinue | Select-Object DisplayName,Enabled,Action | Format-Table -AutoSize
Write-Host '--- Port 9000 / 9121 / 22 listening? ---' -ForegroundColor Cyan
Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $_.LocalPort -in 22,9000,9121 } | Select-Object LocalAddress,LocalPort | Format-Table -AutoSize
Write-Log 'Health check run'

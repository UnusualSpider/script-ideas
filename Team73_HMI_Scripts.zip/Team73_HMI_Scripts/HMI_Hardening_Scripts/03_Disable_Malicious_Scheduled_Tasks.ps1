#Requires -RunAsAdministrator
param([switch]$Undo)
$Global:ScriptName = '03_Disable_Malicious_Scheduled_Tasks'
. "$PSScriptRoot\_common.ps1"

# Fix: two disguised tasks run as SYSTEM and point to missing scripts in C:\Windows\Temp
# (any user could drop a script there and get full control). Exports each task as evidence, then disables it.
$names = @('DnsClientCacheMaintenance','Ignition Helper')
if ($Undo) {
    foreach ($n in $names) { Enable-ScheduledTask -TaskName $n -ErrorAction SilentlyContinue | Out-Null; Write-Log "UNDO: re-enabled task '$n'" 'Yellow' }
    exit
}
Confirm-Run 'Export and disable the tasks: DnsClientCacheMaintenance, Ignition Helper' 'Low. These tasks are not part of the plant.' 'Run with -Undo (re-enables them)'
foreach ($n in $names) {
    $t = Get-ScheduledTask -TaskName $n -ErrorAction SilentlyContinue
    if (-not $t) { Write-Log "Task '$n' not found." 'Yellow'; continue }
    $xml = Join-Path $Global:HLogDir ('evidence_task_' + ($n -replace '\s','_') + '.xml')
    Export-ScheduledTask -TaskName $n -TaskPath $t.TaskPath | Out-File $xml
    Disable-ScheduledTask -TaskName $n -TaskPath $t.TaskPath | Out-Null
    Write-Log "Disabled task '$n' (evidence: $xml)" 'Green'
}
foreach ($f in 'C:\Windows\Temp\dns-cache-refresh.ps1','C:\Windows\Temp\ignition_ui.ps1') {
    if (Test-Path $f) { Write-Log "WARNING: $f EXISTS. Save it as evidence (Get-Content / Get-FileHash) and report it!" 'Red' }
}

#Requires -RunAsAdministrator
# Removes the monitoring task. Keeps C:\HMI_Monitor (alerts and logs are evidence).
Unregister-ScheduledTask -TaskName 'HMI-BlueTeam-Monitor' -Confirm:$false -ErrorAction SilentlyContinue
Write-Host 'Monitoring task removed. Logs kept in C:\HMI_Monitor.' -ForegroundColor Yellow

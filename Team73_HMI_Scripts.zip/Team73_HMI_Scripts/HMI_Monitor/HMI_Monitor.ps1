#Requires -RunAsAdministrator
<#
  HMI_Monitor.ps1  -  Team 73 HMI watcher (READ-ONLY: it never changes the system)
  Checks the HMI for signs of malicious activity and appends findings to C:\HMI_Monitor\alerts.txt

  Ways to run:
    - Every 10 minutes automatically:  run Install_Monitor_Task.ps1 once (as Administrator)
    - In a PowerShell window instead:   .\HMI_Monitor.ps1 -Loop          (Ctrl+C to stop)
    - One single check:                 .\HMI_Monitor.ps1
    - Re-take the "normal" baseline:    .\HMI_Monitor.ps1 -NewBaseline

  Files (C:\HMI_Monitor):
    alerts.txt        every finding, newest at the bottom  (READ THIS)
    monitor_runs.txt  one line per run (proves the monitor is alive)
    allowlist.txt     IPs you trust (your VPN IPs, scoring IP). One per line.
    data\             baseline and state files
#>
param([switch]$Loop, [int]$IntervalMinutes = 10, [switch]$NewBaseline)

$ErrorActionPreference = 'Continue'
$Root      = 'C:\HMI_Monitor'
$DataDir   = Join-Path $Root 'data'
$AlertFile = Join-Path $Root 'alerts.txt'
$RunFile   = Join-Path $Root 'monitor_runs.txt'
$AllowFile = Join-Path $Root 'allowlist.txt'
$SeenFile  = Join-Path $DataDir 'seen.txt'
$MySqlExe  = 'C:\Program Files\MySQL\MySQL Server 8.4\bin\mysql.exe'
$SelfTask  = 'HMI-BlueTeam-Monitor'
New-Item $DataDir -ItemType Directory -Force | Out-Null

# ---------------- known names ----------------
$TeamHosts     = @('10.0.32.140','10.0.32.141','10.0.32.142','10.0.32.143','10.0.32.144','10.0.32.145')
$WatchAccounts = @('svc-hist$','brady','hammon','walton','administrator','network-admin','historian_svc')
$NormalNetUsers= @('score1','score2','patch','blueteam','anonymous logon')
$SensitivePorts= @(22,445,3306,3389,5985,8060,8088,9000,9121,33060,47001)
$BadRemotePorts= @(1337,4444,4445,5555,6666,6667,8888,9001,31337)
$ShellNames    = 'cmd.exe','powershell.exe','pwsh.exe','rundll32.exe','regsvr32.exe','mshta.exe','wscript.exe','cscript.exe','certutil.exe','bitsadmin.exe','whoami.exe','net.exe','net1.exe','nc.exe','ncat.exe','psexesvc.exe','wmic.exe','schtasks.exe','reg.exe','vssadmin.exe'
$BadParents    = 'java.exe','javaw.exe','mysqld.exe','syncbrs.exe','sshd.exe','wsmprovhost.exe','spoolsv.exe','w3wp.exe','tftpserversp.exe','ignitiongateway.exe'
$BadCmdRegex   = '(?i)(-enc(odedcommand)?\s|frombase64string|downloadstring|downloadfile|invoke-webrequest|iwr\s|invoke-expression|\biex\b|-w(indowstyle)?\s+hidden|net\s+user\s+\S+\s+\S+\s+/add|net\s+localgroup\s+administrators|mimikatz|sekurlsa|procdump|comsvcs\.dll|vssadmin\s+delete|wevtutil\s+cl|add-mppreference|set-mppreference\s+-disable)'
$TrapFiles     = 'C:\Windows\Temp\dns-cache-refresh.ps1','C:\Windows\Temp\ignition_ui.ps1'
$ScriptExt     = '\.(exe|dll|ps1|psm1|bat|cmd|vbs|vbe|js|jse|hta|scr|jar|py|sys|msi|lnk|wsf)$'

# ---------------- helpers ----------------
$script:NewAlerts = 0
$script:Seen = New-Object 'System.Collections.Generic.HashSet[string]'
if (Test-Path $SeenFile) { Get-Content $SeenFile | ForEach-Object { [void]$script:Seen.Add($_) } }

function Alert([string]$Sev, [string]$Cat, [string]$Msg, [string]$Key) {
    if (-not $Key) { $Key = "$Cat|$Msg" }
    if ($script:Seen.Contains($Key)) { return }
    [void]$script:Seen.Add($Key); Add-Content $SeenFile $Key
    $line = '{0} | {1,-8} | {2,-11} | {3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Sev, $Cat, $Msg
    Add-Content $AlertFile $line
    $script:NewAlerts++
    $color = 'Gray'
    if ($Sev -eq 'CRITICAL') { $color = 'Red' } elseif ($Sev -eq 'HIGH') { $color = 'Magenta' } elseif ($Sev -eq 'MEDIUM') { $color = 'Yellow' }
    Write-Host $line -ForegroundColor $color
    if ($Loop -and ($Sev -eq 'CRITICAL' -or $Sev -eq 'HIGH')) { [console]::Beep(1000,300) }
}
function Safe([string]$Name, [scriptblock]$Block) {
    try { & $Block } catch { Add-Content $RunFile ('{0}  check "{1}" error: {2}' -f (Get-Date -Format 'HH:mm:ss'), $Name, $_.Exception.Message) }
}
function Get-Allow {
    if (Test-Path $AllowFile) { Get-Content $AllowFile | ForEach-Object { ($_ -split '#')[0].Trim() } | Where-Object { $_ } } else { @() }
}
function Test-Trusted([string]$Ip) {
    if (-not $Ip -or $Ip -match '^(127\.|::1$|0\.0\.0\.0$|::$|-$)') { return $true }
    if ($TeamHosts -contains $Ip) { return $true }
    if ((Get-Allow) -contains $Ip) { return $true }
    return $false
}
function Hist([string]$Sql) {
    if (-not (Test-Path $MySqlExe)) { return @() }
    & $MySqlExe -u historian '-pCyberForce2026!' -N -B -e $Sql 2>$null
}
function Snap-Users   { Get-LocalUser | ForEach-Object { '{0}|enabled={1}' -f $_.Name, $_.Enabled } }
function Snap-Group($g) {
    try { Get-LocalGroupMember $g -ErrorAction Stop | ForEach-Object { $_.Name } }
    catch {   # fallback if a member cannot be resolved
        $lines = net localgroup "$g" 2>$null
        $on = $false
        foreach ($l in $lines) { if ($l -match '^-{5,}') { $on = $true; continue }; if ($l -match 'command completed') { break }; if ($on -and $l.Trim()) { $l.Trim() } }
    }
}
function Snap-Tasks   { Get-ScheduledTask | Where-Object { $_.TaskName -ne $SelfTask } | ForEach-Object { '{0}{1}|{2}|{3} {4}' -f $_.TaskPath, $_.TaskName, $_.State, ($_.Actions.Execute -join ';'), ($_.Actions.Arguments -join ';') } }
function Snap-Services{ Get-CimInstance Win32_Service | ForEach-Object { '{0}|{1}|{2}' -f $_.Name, $_.StartMode, $_.PathName } }
function Snap-Ports   { Get-NetTCPConnection -State Listen | Where-Object { $_.LocalAddress -notmatch '^(127\.|::1$)' } | Sort-Object LocalPort -Unique | ForEach-Object { 'tcp/' + $_.LocalPort } }
function Snap-Firewall{ Get-NetFirewallRule -Enabled True -Direction Inbound -Action Allow | ForEach-Object { $_.DisplayName } | Sort-Object -Unique }
function Snap-RunKeys {
    foreach ($k in 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce') {
        $p = Get-ItemProperty $k -ErrorAction SilentlyContinue
        if ($p) { $p.PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' } | ForEach-Object { "$k|$($_.Name)|$($_.Value)" } }
    }
    Get-ChildItem 'C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp','C:\Users\*\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup' -Force -ErrorAction SilentlyContinue | ForEach-Object { 'startup|' + $_.FullName }
}
function Snap-DbUsers { Hist "SELECT CONCAT(user,'@',host,'|locked=',account_locked) FROM mysql.user;" }

$Snaps = [ordered]@{
    'users'    = { Snap-Users }
    'admins'   = { Snap-Group 'Administrators' }
    'rdp'      = { Snap-Group 'Remote Desktop Users' }
    'tasks'    = { Snap-Tasks }
    'services' = { Snap-Services }
    'ports'    = { Snap-Ports }
    'firewall' = { Snap-Firewall }
    'autoruns' = { Snap-RunKeys }
    'dbusers'  = { Snap-DbUsers }
}
$SnapSeverity = @{ users='HIGH'; admins='CRITICAL'; rdp='HIGH'; tasks='HIGH'; services='HIGH'; ports='HIGH'; firewall='MEDIUM'; autoruns='HIGH'; dbusers='HIGH' }

function Save-Baseline {
    foreach ($k in $Snaps.Keys) { & $Snaps[$k] | Set-Content (Join-Path $DataDir "base_$k.txt") }
    Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue | Where-Object { $_.RemoteAddress -in '10.0.32.143','10.0.32.144' } |
        ForEach-Object { $_.RemoteAddress } | Sort-Object -Unique | Set-Content (Join-Path $DataDir 'base_plcconns.txt')
    Add-Content $RunFile ('{0}  Baseline saved.' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    Write-Host 'Baseline saved.' -ForegroundColor Green
}

# ---------------- one full check ----------------
function Invoke-Check {
    $start = Get-Date
    $script:NewAlerts = 0
    $lastFile = Join-Path $DataDir 'lastrun.txt'
    if (Test-Path $lastFile) { $since = [datetime](Get-Content $lastFile -Raw).Trim() } else { $since = (Get-Date).AddMinutes(-15) }
    $since = $since.AddSeconds(-30)   # small overlap so nothing slips between runs

    # 1. Changes since baseline
    Safe 'baseline' {
        foreach ($k in $Snaps.Keys) {
            $bf = Join-Path $DataDir "base_$k.txt"
            if (-not (Test-Path $bf)) { continue }
            $old = @(Get-Content $bf); $now = @(& $Snaps[$k])
            foreach ($d in (Compare-Object $old $now)) {
                if ($d.SideIndicator -eq '=>') { Alert $SnapSeverity[$k] ('NEW-' + $k.ToUpper()) ('Added/changed vs baseline: ' + $d.InputObject) }
                else { Alert 'MEDIUM' ('GONE-' + $k.ToUpper()) ('Missing/changed vs baseline: ' + $d.InputObject) }
            }
        }
    }

    # 2. Critical services
    Safe 'services' {
        foreach ($s in 'Ignition','MySQL84','WinDefend','mpssvc','EventLog') {
            $svc = Get-Service $s -ErrorAction SilentlyContinue
            if ($svc -and $svc.Status -ne 'Running') { Alert 'CRITICAL' 'SERVICE' "$s is $($svc.Status)" ("svc|$s|" + (Get-Date -Format 'yyyyMMddHHmm')) }
        }
    }

    # 3. Logins
    Safe 'logins' {
        $ev = Get-WinEvent -FilterHashtable @{LogName='Security';Id=4624;StartTime=$since} -ErrorAction SilentlyContinue
        foreach ($e in $ev) {
            $type = [int]$e.Properties[8].Value; if ($type -notin 3,10) { continue }
            $user = "$($e.Properties[5].Value)"; $ip = "$($e.Properties[18].Value)"; $lu = $user.ToLower()
            $key = 'evt|' + $e.RecordId
            if ($WatchAccounts -contains $lu -or $lu -like 'old.*') { Alert 'HIGH' 'LOGIN' "Watch-list account '$user' logged in (type $type) from $ip at $($e.TimeCreated)" $key }
            elseif ($type -eq 10 -and $lu -ne 'blueteam') { Alert 'HIGH' 'LOGIN' "RDP login by '$user' from $ip at $($e.TimeCreated)" $key }
            elseif ($type -eq 10 -and -not (Test-Trusted $ip)) { Alert 'MEDIUM' 'LOGIN' "blueteam RDP login from untrusted IP $ip at $($e.TimeCreated) (add your VPN IP to allowlist.txt)" ("rdpip|$ip") }
            elseif ($type -eq 3 -and $NormalNetUsers -notcontains $lu -and -not $lu.EndsWith('$')) { Alert 'MEDIUM' 'LOGIN' "Network login by '$user' from $ip at $($e.TimeCreated)" ("net|$lu|$ip") }
        }
        $fails = Get-WinEvent -FilterHashtable @{LogName='Security';Id=4625;StartTime=$since} -ErrorAction SilentlyContinue
        if ($fails) {
            $fails | Group-Object { "$($_.Properties[5].Value) from $($_.Properties[19].Value)" } | ForEach-Object {
                $sev = 'INFO'; if ($_.Count -ge 5) { $sev = 'HIGH' }
                Alert $sev 'FAILED-LOGIN' ("$($_.Count) failed logins: $($_.Name) since $since") ('fail|' + $_.Name + '|' + (Get-Date -Format 'yyyyMMddHHmm'))
            }
        }
        $rdp = Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-TerminalServices-LocalSessionManager/Operational';Id=21,25;StartTime=$since} -ErrorAction SilentlyContinue
        foreach ($e in $rdp) {
            $u = "$($e.Properties[0].Value)"; $a = "$($e.Properties[2].Value)"
            if ($u -notmatch '\\blueteam$') { Alert 'HIGH' 'RDP-SESSION' "RDP session by $u from $a at $($e.TimeCreated)" ('evt|rdp|' + $e.RecordId) }
        }
        $ssh = Get-WinEvent -FilterHashtable @{LogName='OpenSSH/Operational';StartTime=$since} -ErrorAction SilentlyContinue | Where-Object { $_.Message -match 'Accepted|Failed password|Invalid user' }
        foreach ($e in $ssh) { Alert 'HIGH' 'SSH' ("$($e.TimeCreated) " + ($e.Message -replace '\s+',' ')) ('evt|ssh|' + $e.RecordId) }
    }

    # 4. Account changes, new services, cleared logs
    Safe 'changes' {
        $names = @{4720='User account CREATED';4722='Account ENABLED';4724='Password RESET';4728='Added to global group';4732='Added to LOCAL GROUP';4738='Account CHANGED';1102='SECURITY LOG CLEARED'}
        Get-WinEvent -FilterHashtable @{LogName='Security';Id=4720,4722,4724,4728,4732,4738,1102;StartTime=$since} -ErrorAction SilentlyContinue | ForEach-Object {
            $sev = 'HIGH'; if ($_.Id -in 1102,4720,4732) { $sev = 'CRITICAL' }
            $detail = (($_.Message -split "`n" | Where-Object { $_ -match 'Account Name|Group Name|Member' } | ForEach-Object { $_.Trim() }) -join '; ')
            Alert $sev 'ACCOUNT' ("Event $($_.Id) $($names[$_.Id]) at $($_.TimeCreated): $detail") ('evt|sec|' + $_.RecordId)
        }
        Get-WinEvent -FilterHashtable @{LogName='System';Id=7045,104;StartTime=$since} -ErrorAction SilentlyContinue | ForEach-Object {
            $what = 'NEW SERVICE INSTALLED'; $sev = 'HIGH'; if ($_.Id -eq 104) { $what = 'LOG CLEARED'; $sev = 'CRITICAL' }
            Alert $sev 'SYSTEM' ("Event $($_.Id) $what at $($_.TimeCreated): " + (($_.Message -replace '\s+',' ').Substring(0, [Math]::Min(300, ($_.Message -replace '\s+',' ').Length)))) ('evt|sys|' + $_.RecordId)
        }
    }

    # 5. Defender and firewall
    Safe 'defender' {
        $mp = Get-MpComputerStatus -ErrorAction SilentlyContinue
        if ($mp -and -not $mp.RealTimeProtectionEnabled) { Alert 'CRITICAL' 'DEFENDER' 'Real-time protection is OFF' ('rtp|' + (Get-Date -Format 'yyyyMMddHH')) }
        $pref = Get-MpPreference -ErrorAction SilentlyContinue
        foreach ($x in @($pref.ExclusionPath) + @($pref.ExclusionProcess) + @($pref.ExclusionExtension)) { if ($x) { Alert 'HIGH' 'DEFENDER' "Exclusion present: $x" } }
        Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Windows Defender/Operational';Id=1116,1117,5001,5007;StartTime=$since} -ErrorAction SilentlyContinue | ForEach-Object {
            $sev = 'HIGH'; if ($_.Id -in 1116,5001) { $sev = 'CRITICAL' }
            Alert $sev 'DEFENDER' ("Event $($_.Id) at $($_.TimeCreated): " + (($_.Message -split "`n")[0].Trim())) ('evt|def|' + $_.RecordId)
        }
        Get-NetFirewallProfile | Where-Object { -not $_.Enabled } | ForEach-Object { Alert 'HIGH' 'FIREWALL' "Firewall profile $($_.Name) is OFF" }
        Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Windows Firewall With Advanced Security/Firewall';Id=2004,2005,2006;StartTime=$since} -ErrorAction SilentlyContinue |
            Where-Object { $_.Message -notmatch 'HMI-Harden' } | ForEach-Object {
                Alert 'MEDIUM' 'FIREWALL' ("Rule event $($_.Id) (2004 add, 2005 change, 2006 delete) at $($_.TimeCreated): " + ((($_.Message -split "`n") | Where-Object { $_ -match 'Rule Name' } | Select-Object -First 1) -replace '\s+',' ')) ('evt|fw|' + $_.RecordId)
            }
    }

    # 6. Suspicious processes
    Safe 'processes' {
        $all = Get-CimInstance Win32_Process
        $byId = @{}; foreach ($p in $all) { $byId[[int]$p.ProcessId] = $p }
        foreach ($p in $all) {
            if ($p.ProcessId -eq $PID -or "$($p.CommandLine)" -match 'HMI_Monitor|HMI_Hardening') { continue }
            $name = "$($p.Name)".ToLower(); $parent = $byId[[int]$p.ParentProcessId]; $pname = ''
            if ($parent) { $pname = "$($parent.Name)".ToLower() }
            $key = "proc|$($p.ProcessId)|$name"
            if ($ShellNames -contains $name -and $BadParents -contains $pname) { Alert 'CRITICAL' 'PROCESS' "$name (PID $($p.ProcessId)) started by $pname : $($p.CommandLine)" $key; continue }
            if ("$($p.CommandLine)" -match $BadCmdRegex) { Alert 'HIGH' 'PROCESS' "Suspicious command line in $name (PID $($p.ProcessId), parent $pname): $($p.CommandLine)" $key; continue }
            if ("$($p.ExecutablePath)" -match '(?i)\\(Windows\\Temp|Users\\Public|ProgramData\\[^\\]+\.exe|Downloads|AppData\\Local\\Temp)\\' -and "$($p.ExecutablePath)" -notmatch '(?i)JxBrowser|\.ignition') {
                Alert 'HIGH' 'PROCESS' "Program running from a suspicious folder: $($p.ExecutablePath) (PID $($p.ProcessId))" $key
            }
        }
        $ps = Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-PowerShell/Operational';Id=4104;StartTime=$since} -ErrorAction SilentlyContinue
        foreach ($e in $ps) {
            $txt = "$($e.Properties[2].Value)"; $path = "$($e.Properties[4].Value)"
            if ($path -match 'HMI_Monitor|HMI_Hardening' -or $txt -match 'HMI_Monitor') { continue }
            if ($txt -match $BadCmdRegex) { Alert 'HIGH' 'POWERSHELL' ("Suspicious script ran at $($e.TimeCreated): " + $txt.Substring(0,[Math]::Min(300,$txt.Length)) -replace '\s+',' ') ('evt|ps|' + $e.RecordId) }
        }
    }

    # 7. Network connections
    Safe 'network' {
        $procs = @{}; Get-Process | ForEach-Object { $procs[$_.Id] = $_.ProcessName }
        Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue | ForEach-Object {
            $r = $_.RemoteAddress; $pn = "$($procs[[int]$_.OwningProcess])"
            if ($r -match '^(127\.|::1$)') { return }
            if ($SensitivePorts -contains [int]$_.LocalPort -and -not (Test-Trusted $r)) {
                $sev = 'HIGH'; if ([int]$_.LocalPort -in 3389,8088) { $sev = 'MEDIUM' }
                Alert $sev 'NETWORK' "Inbound connection from $r to HMI port $($_.LocalPort) ($pn)" ("conn|$r|$($_.LocalPort)")
            }
            if ($BadRemotePorts -contains [int]$_.RemotePort) { Alert 'HIGH' 'NETWORK' "Connection to suspicious port $r`:$($_.RemotePort) by $pn" ("out|$r|$($_.RemotePort)") }
            if (($ShellNames -replace '\.exe$','') -contains $pn.ToLower()) { Alert 'CRITICAL' 'NETWORK' "Shell/tool '$pn' has a network connection to $r`:$($_.RemotePort)" ("shellnet|$pn|$r") }
            if ($TeamHosts -contains $r -and [int]$_.RemotePort -in 3389,5985,445,22 -and [int]$_.LocalPort -gt 1024) { Alert 'MEDIUM' 'LATERAL' "HMI connecting OUT to $r`:$($_.RemotePort) ($pn) - possible lateral movement" ("lat|$r|$($_.RemotePort)|$pn") }
        }
    }

    # 8. Files dropped in hiding places
    Safe 'files' {
        foreach ($f in $TrapFiles) {
            if (Test-Path $f) {
                $i = Get-Item $f; $h = (Get-FileHash $f).Hash; $owner = (Get-Acl $f).Owner
                Alert 'CRITICAL' 'TRAP-FILE' "$f EXISTS (runs as SYSTEM via hidden task). Owner $owner, written $($i.LastWriteTime), SHA256 $h" ("trap|$f|$h")
            }
        }
        $dirs = 'C:\Windows\Temp','C:\Users\Public','C:\ProgramData','C:\Windows\Tasks','C:\PerfLogs'
        $dirs += (Get-ChildItem 'C:\Users' -Directory -Force -ErrorAction SilentlyContinue | ForEach-Object { Join-Path $_.FullName 'Downloads'; Join-Path $_.FullName 'Desktop'; Join-Path $_.FullName 'AppData\Local\Temp'; Join-Path $_.FullName 'AppData\Roaming' })
        foreach ($d in $dirs) {
            if (-not (Test-Path $d)) { continue }
            Get-ChildItem $d -Recurse -File -Force -ErrorAction SilentlyContinue |
                Where-Object { $_.LastWriteTime -gt $since -and $_.Name -match $ScriptExt -and $_.FullName -notmatch '(?i)Windows Defender|\\Microsoft\\Windows\\|JxBrowser|\\\.ignition\\|HMI_Monitor|HMI_Hardening|\\Amazon\\|\\Package Cache\\|\\Google\\|\\Microsoft\\Edge' } |
                ForEach-Object { Alert 'HIGH' 'NEW-FILE' "New/changed executable or script: $($_.FullName) ($($_.Length) bytes, $($_.LastWriteTime))" ("file|$($_.FullName)|$($_.LastWriteTime.Ticks)") }
        }
    }

    # 9. Advanced persistence
    Safe 'persistence' {
        Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options' -ErrorAction SilentlyContinue | ForEach-Object {
            $dbg = (Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue).Debugger
            if ($dbg) { Alert 'CRITICAL' 'PERSIST' "Debugger hijack on $($_.PSChildName): $dbg" }
        }
        Get-CimInstance -Namespace root\subscription -ClassName CommandLineEventConsumer -ErrorAction SilentlyContinue | ForEach-Object { Alert 'CRITICAL' 'PERSIST' "WMI command consumer '$($_.Name)': $($_.CommandLineTemplate)" }
        Get-CimInstance -Namespace root\subscription -ClassName ActiveScriptEventConsumer -ErrorAction SilentlyContinue | ForEach-Object { Alert 'CRITICAL' 'PERSIST' "WMI script consumer '$($_.Name)'" }
    }

    # 10. Historian database
    Safe 'database' {
        Hist "SELECT CONCAT(user,'@',host,' db=',IFNULL(db,'-'),' cmd=',command) FROM information_schema.processlist WHERE host NOT LIKE 'localhost%' AND host NOT LIKE '127.0.0.1%' AND host NOT LIKE '::1%' AND user<>'event_scheduler';" |
            ForEach-Object { if ($_) { Alert 'HIGH' 'DATABASE' "Remote database connection: $_" ("db|" + ($_ -replace ':\d+',''))} }
        Hist "SELECT CONCAT(trigger_schema,'.',trigger_name,' on ',event_object_table) FROM information_schema.triggers WHERE trigger_schema NOT IN ('sys','mysql');" | ForEach-Object { if ($_) { Alert 'HIGH' 'DATABASE' "Database TRIGGER exists: $_" } }
        Hist "SELECT CONCAT(event_schema,'.',event_name,' ',status) FROM information_schema.events;" | ForEach-Object { if ($_) { Alert 'HIGH' 'DATABASE' "Database scheduled EVENT exists: $_" } }
        $rowsFile = Join-Path $DataDir 'db_rows.txt'
        $now = @(Hist "SELECT CONCAT(table_name,'|',IFNULL(table_rows,0),'|',IFNULL(update_time,'')) FROM information_schema.tables WHERE table_schema='historian';")
        if (Test-Path $rowsFile) {
            $prev = @{}; Get-Content $rowsFile | ForEach-Object { $p = $_ -split '\|'; $prev[$p[0]] = $p }
            $stale = $true
            foreach ($l in $now) {
                $p = $l -split '\|'
                if ($prev.ContainsKey($p[0])) {
                    $o = $prev[$p[0]]
                    if ([long]$p[1] -lt ([long]$o[1] * 0.8) -and [long]$o[1] -gt 100) { Alert 'HIGH' 'DATABASE' "Historian table $($p[0]) row count DROPPED from about $($o[1]) to $($p[1]) (possible deleted history)" }
                    if ($p[2] -ne $o[2]) { $stale = $false }
                } else { $stale = $false }
            }
            if ($now.Count -gt 0 -and $stale) { Alert 'MEDIUM' 'DATABASE' 'Historian tables have not been updated since the last check (data may have stopped flowing)' ('stale|' + (Get-Date -Format 'yyyyMMddHH')) }
        }
        if ($now.Count -gt 0) { $now | Set-Content $rowsFile }
    }

    # 11. Plant connectivity (passive: looks at existing connections, never opens new ones to the PLCs)
    Safe 'plc' {
        $plc = @(Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue | Where-Object { $_.RemoteAddress -in '10.0.32.143','10.0.32.144' })
        $basePlc = Join-Path $DataDir 'base_plcconns.txt'
        if (Test-Path $basePlc) {
            $had = @(Get-Content $basePlc)
            foreach ($ip in $had) { if ($ip -and -not ($plc | Where-Object { $_.RemoteAddress -eq $ip })) { Alert 'HIGH' 'PLANT' "HMI no longer has a connection to PLC $ip (it did at baseline)" ('plc|' + $ip + '|' + (Get-Date -Format 'yyyyMMddHH')) } }
        }
    }

    (Get-Date).ToString('o') | Set-Content $lastFile
    $secs = [int]((Get-Date) - $start).TotalSeconds
    $msg = '{0}  run OK  new alerts: {1}  ({2}s)' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $script:NewAlerts, $secs
    Add-Content $RunFile $msg
    Write-Host $msg -ForegroundColor Cyan
}

# ---------------- main ----------------
if ($NewBaseline -or -not (Test-Path (Join-Path $DataDir 'base_users.txt'))) { Save-Baseline }
if (-not (Test-Path $AlertFile)) { Add-Content $AlertFile 'TIME                | SEVERITY | CATEGORY    | DETAILS' }

if ($Loop) {
    Write-Host "HMI monitor running every $IntervalMinutes minutes. Alerts go to $AlertFile. Press Ctrl+C to stop." -ForegroundColor Green
    while ($true) { Invoke-Check; Start-Sleep -Seconds ($IntervalMinutes * 60) }
} else {
    Invoke-Check
}

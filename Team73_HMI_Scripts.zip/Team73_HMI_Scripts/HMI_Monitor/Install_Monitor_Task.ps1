#Requires -RunAsAdministrator
<#
  Installs HMI_Monitor.ps1 as a scheduled task that runs every 10 minutes as SYSTEM.
  - Copies the monitor to C:\HMI_Monitor and locks that folder so ONLY SYSTEM and Administrators can change it
    (otherwise the task itself would become a backdoor, just like the planted tasks on this box).
  - Takes the "normal" baseline right now.
  - The task runs for 3 days, then stops by itself.
  This creates a scheduled task on an Assume Breach machine. Monitoring tools are allowed "at your own risk";
  confirm with your team first. Prefer "HMI_Monitor.ps1 -Loop" in a window if you want zero system changes.
#>
param([int]$IntervalMinutes = 10)
$Root = 'C:\HMI_Monitor'
$Task = 'HMI-BlueTeam-Monitor'
$a = Read-Host 'Team agreed to install a monitoring task on the HMI? Type YES'
if ($a -ne 'YES') { Write-Host 'Cancelled.'; exit 1 }

New-Item $Root -ItemType Directory -Force | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'HMI_Monitor.ps1') $Root -Force
if (-not (Test-Path "$Root\allowlist.txt")) {
@'
# Trusted IP addresses, one per line. Add the team VPN IPs and the scoring/scoreboard IP.
# Team machines 10.0.32.140-145 are trusted automatically.
'@ | Set-Content "$Root\allowlist.txt"
}
# Lock the folder: SYSTEM + Administrators full control, nobody else can write.
icacls $Root /inheritance:r /grant:r 'SYSTEM:(OI)(CI)F' 'Administrators:(OI)(CI)F' | Out-Null
Write-Host 'Folder permissions locked to SYSTEM and Administrators.' -ForegroundColor Green

# Baseline now (as you), then register the task.
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$Root\HMI_Monitor.ps1" -NewBaseline

$action  = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$Root\HMI_Monitor.ps1`""
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes $IntervalMinutes) -RepetitionDuration (New-TimeSpan -Days 3)
$princ   = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$set     = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 8) -MultipleInstances IgnoreNew -StartWhenAvailable
Register-ScheduledTask -TaskName $Task -Action $action -Trigger $trigger -Principal $princ -Settings $set -Description 'Team 73 Blue Team read-only HMI monitor' -Force | Out-Null
Write-Host "Task '$Task' installed: runs every $IntervalMinutes minutes as SYSTEM." -ForegroundColor Green
Write-Host "Watch alerts with:   Get-Content $Root\alerts.txt -Wait -Tail 30" -ForegroundColor Cyan
Write-Host "Proof it is running: Get-Content $Root\monitor_runs.txt -Tail 5" -ForegroundColor Cyan

HMI MONITOR - Team 73
=====================
What it does (READ-ONLY - it never changes the system):
Every 10 minutes it checks the HMI and writes anything suspicious to C:\HMI_Monitor\alerts.txt

  - Changes vs the baseline: users, Administrators, Remote Desktop Users, scheduled tasks, services,
    listening ports, firewall allow rules, Run keys / startup folders, database users
  - Ignition, MySQL, Defender, Firewall, Event Log services stopped
  - Logins by watch-list accounts (svc-hist$, old.*, brady, hammon, walton, Administrator, network-admin),
    RDP by anyone but blueteam, failed-login bursts, SSH logins
  - Account created/enabled/reset/added to group, security or system log cleared, new service installed
  - Defender off, exclusions added, malware detections; firewall profile off or rules changed
  - Shells started by java/mysqld/syncbrs/sshd/etc., encoded or download commands, programs in Temp folders,
    suspicious PowerShell script blocks
  - Connections to sensitive HMI ports from untrusted IPs, connections to known-bad ports,
    shells with network connections, HMI connecting out to other team machines (lateral movement)
  - New scripts/executables in Temp, Public, ProgramData, Downloads, Desktop, AppData
  - THE TWO TRAP FILES: C:\Windows\Temp\dns-cache-refresh.ps1 and ignition_ui.ps1
  - Debugger hijacks and WMI persistence
  - Historian: remote DB connections, triggers, events, row counts dropping, data no longer updating
  - HMI losing its existing connection to a PLC (passive check - never opens connections to the PLCs)

Each finding is written ONCE (no repeats every 10 minutes).

HOW TO RUN - pick ONE
---------------------
Option A (recommended, no system change): open PowerShell as Administrator, then
    cd <folder with this file>
    powershell -ExecutionPolicy Bypass -File .\HMI_Monitor.ps1 -Loop
  Leave the window open. It beeps on HIGH/CRITICAL. Ctrl+C stops it.
  Data goes to C:\HMI_Monitor.

Option B (runs even if you disconnect): creates a scheduled task (a change on an Assume Breach box - get team OK)
    powershell -ExecutionPolicy Bypass -File .\Install_Monitor_Task.ps1
  Remove later with Uninstall_Monitor_Task.ps1

WATCH THE ALERTS (second PowerShell window):
    Get-Content C:\HMI_Monitor\alerts.txt -Wait -Tail 30
CHECK IT IS ALIVE:
    Get-Content C:\HMI_Monitor\monitor_runs.txt -Tail 5

FIRST THING TO DO
-----------------
1. Put your VPN IPs and the scoring IP in C:\HMI_Monitor\allowlist.txt (one per line), or you will get
   "untrusted IP" alerts for yourselves.
2. The first run takes the baseline. Take it at the START of the competition.
3. After you run hardening scripts (which change services/firewall), re-take the baseline so you only see
   NEW changes:   .\HMI_Monitor.ps1 -NewBaseline     (Option B: C:\HMI_Monitor\HMI_Monitor.ps1 -NewBaseline)

READING ALERTS
--------------
Format:  time | severity | category | details
CRITICAL = act/report now. HIGH = investigate now. MEDIUM = check soon. INFO = background.
Expect some noise (e.g. a Windows service changing start type, Ignition ports changing after a restart).
Every alert is a lead, not proof. Confirm it with the Field Manual playbooks, then report.

NOTES
-----
- Needs Administrator (or SYSTEM). Reads the Security log, so some checks need auditing enabled
  (Field Manual Section 4, step 9).
- Untested on your exact machine: run it once BEFORE competition day (it is read-only) and check
  C:\HMI_Monitor\monitor_runs.txt for "error" lines.
